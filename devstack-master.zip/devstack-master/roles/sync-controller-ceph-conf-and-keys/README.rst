Sync ceph config and keys between controller and subnodes

Simply copy the contents of /etc/ceph on the controller to subnodes.
